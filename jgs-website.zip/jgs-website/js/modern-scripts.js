/**
 * JGS Industries - Modern UI Scripts
 * This script handles animations and interactions for modern UI elements
 */

document.addEventListener('DOMContentLoaded', function () {
    // Add scroll effects to header
    const header = document.querySelector('header');
    const heroSection = document.querySelector('.modern-hero') || document.querySelector('.hero');

    if (header && heroSection) {
        addScrollHeaderEffect(header);
    }

    // Initialize animated elements
    initAnimatedElements();

    // Modern contact form validation
    const modernContactForm = document.getElementById('modernContactForm');
    if (modernContactForm) {
        initContactForm(modernContactForm);
    }

    // Product card animation
    const productCards = document.querySelectorAll('.product-card, .modern-product-card');
    initProductCards(productCards);

    /**
     * Adds scroll effect to header (shrink on scroll)
     * @param {HTMLElement} header - The header element
     */
    function addScrollHeaderEffect(header) {
        const scrollHandler = () => {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        };

        // Initial check
        scrollHandler();

        // Add scroll event listener
        window.addEventListener('scroll', scrollHandler);
    }

    /**
     * Initializes animations for elements when they come into view
     */
    function initAnimatedElements() {
        // Elements to animate
        const animatedElements = document.querySelectorAll('.section-title, .glass-3d-container, .product-card, .modern-product-card');

        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('animated');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.2 });

            animatedElements.forEach(element => {
                observer.observe(element);
            });
        } else {
            // Fallback for browsers without IntersectionObserver
            animatedElements.forEach(element => {
                element.classList.add('animated');
            });
        }
    }

    /**
     * Initializes contact form validation
     * @param {HTMLElement} form - The form element
     */
    function initContactForm(form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();

            // Basic form validation
            let isValid = true;

            // Required fields
            const required = form.querySelectorAll('[required]');
            required.forEach(field => {
                if (!field.value.trim()) {
                    showError(field, 'This field is required');
                    isValid = false;
                } else {
                    clearError(field);
                }
            });

            // Email validation
            const email = form.querySelector('#email');
            if (email && email.value.trim() && !isValidEmail(email.value)) {
                showError(email, 'Please enter a valid email address');
                isValid = false;
            }

            // If form is valid, show success message
            if (isValid) {
                showFormSuccess(form);
            }
        });

        // Clear error on input
        const inputs = form.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            input.addEventListener('input', function () {
                clearError(input);
            });
        });
    }

    /**
     * Shows error message for form field
     * @param {HTMLElement} field - The form field
     * @param {string} message - The error message
     */
    function showError(field, message) {
        // Clear existing error
        clearError(field);

        // Add error styles
        field.classList.add('error');

        // Create error message
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        errorDiv.style.color = '#e53e3e';
        errorDiv.style.fontSize = '12px';
        errorDiv.style.marginTop = '4px';

        // Insert error message after field
        field.parentNode.appendChild(errorDiv);
    }

    /**
     * Clears error message for form field
     * @param {HTMLElement} field - The form field
     */
    function clearError(field) {
        field.classList.remove('error');

        // Remove error message if exists
        const errorMessage = field.parentNode.querySelector('.error-message');
        if (errorMessage) {
            errorMessage.remove();
        }
    }

    /**
     * Validates email format
     * @param {string} email - The email to validate
     * @returns {boolean} - Whether the email is valid
     */
    function isValidEmail(email) {
        const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }

    /**
     * Shows success message after form submission
     * @param {HTMLElement} form - The form element
     */
    function showFormSuccess(form) {
        // Create success message
        const successDiv = document.createElement('div');
        successDiv.className = 'success-message';
        successDiv.innerHTML = '<i class="fas fa-check-circle"></i> Thank you! Your message has been sent.';
        successDiv.style.backgroundColor = '#c6f6d5';
        successDiv.style.color = '#276749';
        successDiv.style.padding = '15px';
        successDiv.style.borderRadius = '8px';
        successDiv.style.marginBottom = '20px';
        successDiv.style.display = 'flex';
        successDiv.style.alignItems = 'center';

        // Insert at beginning of form
        form.prepend(successDiv);

        // Reset form
        form.reset();

        // Remove success message after delay
        setTimeout(() => {
            successDiv.remove();
        }, 5000);
    }

    /**
     * Initializes product card animations
     * @param {NodeList} cards - The product cards
     */
    function initProductCards(cards) {
        cards.forEach(card => {
            // Add tilt effect on hover
            card.addEventListener('mousemove', function (e) {
                const cardRect = card.getBoundingClientRect();
                const cardCenterX = cardRect.left + cardRect.width / 2;
                const cardCenterY = cardRect.top + cardRect.height / 2;

                // Calculate mouse position relative to card center (-1 to 1)
                const mouseX = (e.clientX - cardCenterX) / (cardRect.width / 2);
                const mouseY = (e.clientY - cardCenterY) / (cardRect.height / 2);

                // Apply subtle tilt effect
                const tiltAmount = 2; // degrees
                card.style.transform = `perspective(1000px) rotateX(${-mouseY * tiltAmount}deg) rotateY(${mouseX * tiltAmount}deg) translateY(-2px)`;
            });

            // Reset on mouse leave
            card.addEventListener('mouseleave', function () {
                card.style.transform = '';

                // If it's a modern card, add the hover transform
                if (card.classList.contains('modern-product-card')) {
                    card.style.transform = 'translateY(-8px)';
                } else if (card.classList.contains('product-card')) {
                    card.style.transform = 'translateY(-10px)';
                }

                // Transition back to normal
                setTimeout(() => {
                    card.style.transform = '';
                }, 300);
            });
        });
    }

    // Add smooth scroll to anchor links
    const anchorLinks = document.querySelectorAll('a[href^="#"]:not([href="#"])');
    anchorLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();

            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);

            if (targetElement) {
                const headerHeight = document.querySelector('header').offsetHeight;
                const targetPosition = targetElement.offsetTop - headerHeight - 20;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Animation for glass panes in hero section
    const heroCta = document.querySelector('.hero-buttons');
    const glassPanes = document.querySelectorAll('.glass-pane');

    if (heroCta && glassPanes.length > 0) {
        heroCta.addEventListener('mouseenter', () => {
            glassPanes.forEach((pane, index) => {
                const delay = index * 100;
                setTimeout(() => {
                    pane.style.transform = pane.style.transform.replace('rotateY', 'rotateY(5deg) rotateY');
                }, delay);
            });
        });

        heroCta.addEventListener('mouseleave', () => {
            glassPanes.forEach((pane, index) => {
                const delay = index * 100;
                setTimeout(() => {
                    pane.style.transform = pane.style.transform.replace('rotateY(5deg) ', '');
                }, delay);
            });
        });
    }
});