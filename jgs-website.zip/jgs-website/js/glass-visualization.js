/**
 * JGS Industries - 3D Glass Visualization
 * This script handles the interactive 3D glass visualization showcase
 */

document.addEventListener('DOMContentLoaded', function () {
    // Configuration
    const glassTypes = [
        { name: "Tempered Glass", color: "#dbeeff", description: "Heat-treated for enhanced strength" },
        { name: "Double Glazed Glass", color: "#c2e0ff", description: "Superior thermal insulation" },
        { name: "Laminated Glass", color: "#e0f5e0", description: "Enhanced security and safety" },
        { name: "Colored Laminated Glass", color: "#e5dfff", description: "Decorative and protective" },
        { name: "Double Glazed with Georgian Bars", color: "#fff6dd", description: "Classic divided light appearance" },
        { name: "Fabric Glass", color: "#ffe6f2", description: "Embedded fabric for aesthetics" },
        { name: "Switchable Glass", color: "#f1f1f1", description: "On-demand privacy control" },
        { name: "Fire Rated Glass", color: "#ffede0", description: "Fire protection for safety" },
        { name: "Bullet Proof Glass", color: "#bfd9ff", description: "High-security protection" }
    ];

    // DOM elements
    const rotatingContainer = document.getElementById('rotating-showcase');
    const toggleRotationBtn = document.getElementById('toggle-rotation');
    const rotationSpeedInput = document.getElementById('rotation-speed');

    // Variables
    let isRotating = true;
    let rotationSpeed = 20;

    // Create glass panels
    if (rotatingContainer) {
        createGlassPanels();
    }

    // Initialize controls
    if (toggleRotationBtn) {
        toggleRotationBtn.addEventListener('click', toggleRotation);
    }

    if (rotationSpeedInput) {
        rotationSpeedInput.addEventListener('input', updateRotationSpeed);
    }

    /**
     * Creates and adds glass panels to the rotating container
     */
    function createGlassPanels() {
        glassTypes.forEach((glass, index) => {
            // Calculate position in 3D space
            const angle = (360 / glassTypes.length) * index;
            const rotation = `rotateY(${angle}deg) translateZ(300px)`;

            // Create panel
            const glassPanel = document.createElement('div');
            glassPanel.className = 'glass-panel';
            glassPanel.style.backgroundColor = glass.color;
            glassPanel.style.transform = rotation;

            // Add content
            glassPanel.innerHTML = `
                <h3>${glass.name}</h3>
                <p>${glass.description}</p>
            `;

            // Add to container
            rotatingContainer.appendChild(glassPanel);
        });
    }

    /**
     * Toggles the rotation animation
     */
    function toggleRotation() {
        isRotating = !isRotating;

        if (isRotating) {
            rotatingContainer.style.animation = `rotate ${rotationSpeed}s infinite linear`;
            toggleRotationBtn.textContent = 'Pause Rotation';
        } else {
            rotatingContainer.style.animation = 'none';
            toggleRotationBtn.textContent = 'Start Rotation';
        }
    }

    /**
     * Updates the rotation speed based on the slider input
     */
    function updateRotationSpeed() {
        rotationSpeed = rotationSpeedInput.value;

        if (isRotating) {
            rotatingContainer.style.animation = `rotate ${rotationSpeed}s infinite linear`;
        }
    }

    // Product category filtering
    const categoryTabs = document.querySelectorAll('.category-tab');
    const productCards = document.querySelectorAll('.modern-product-card');

    if (categoryTabs.length > 0) {
        categoryTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Remove active class from all tabs
                categoryTabs.forEach(t => t.classList.remove('active'));

                // Add active class to clicked tab
                tab.classList.add('active');

                // Get category to filter
                const category = tab.getAttribute('data-target');

                // Filter products
                filterProducts(category);
            });
        });
    }

    /**
     * Filters product cards based on selected category
     * @param {string} category - The category to filter by
     */
    function filterProducts(category) {
        if (category === 'all') {
            // Show all products
            productCards.forEach(card => {
                card.style.display = 'block';
            });
        } else {
            // Filter products by category
            productCards.forEach(card => {
                const cardCategory = card.getAttribute('data-category');

                if (cardCategory === category) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    }

    // Glass type card hover effects
    const temperedGlass = document.querySelectorAll('.tempered-glass');
    const doubleGlazedGlass = document.querySelectorAll('.double-glazed-glass');
    const laminatedGlass = document.querySelectorAll('.laminated-glass');
    const switchableGlass = document.querySelectorAll('.switchable-glass');

    // Add interactive effects to glass visualizations
    const addHoverEffects = (elements, effectFunction) => {
        elements.forEach(element => {
            const card = element.closest('.modern-product-card') || element.closest('.product-card');

            if (card) {
                card.addEventListener('mouseenter', () => effectFunction(element, true));
                card.addEventListener('mouseleave', () => effectFunction(element, false));
            }
        });
    };

    // Specific effects for each glass type
    const temperedEffect = (element, isHovering) => {
        element.style.transform = isHovering ? 'rotate(16deg) scale(1.05)' : 'rotate(12deg)';
    };

    const doubleGlazedEffect = (element, isHovering) => {
        const front = element.querySelector('.double-glazed-front') || element;
        const back = element.querySelector('.double-glazed-back');

        if (front) front.style.transform = isHovering ? 'translateZ(10px)' : 'translateZ(0)';
        if (back) back.style.transform = isHovering ? 'translateZ(-10px)' : 'translateZ(0)';
    };

    const laminatedEffect = (element, isHovering) => {
        const layers = element.querySelectorAll('.glass-pane') || [element];

        layers.forEach((layer, index) => {
            const offset = isHovering ? (index + 1) * 3 : 0;
            layer.style.transform = isHovering ? `translateY(${-offset}px)` : 'none';
        });
    };

    const switchableEffect = (element, isHovering) => {
        element.style.opacity = isHovering ? '0.9' : '0.6';
        element.style.backgroundColor = isHovering ? '#f8f8f8' : '#d3d3d3';
    };

    // Apply hover effects
    addHoverEffects(temperedGlass, temperedEffect);
    addHoverEffects(doubleGlazedGlass, doubleGlazedEffect);
    addHoverEffects(laminatedGlass, laminatedEffect);
    addHoverEffects(switchableGlass, switchableEffect);
});