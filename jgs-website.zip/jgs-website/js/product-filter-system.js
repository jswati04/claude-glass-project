/**
 * JGS Industries - Enhanced Product Filtering System
 * This script provides advanced filtering for product grid
 */

document.addEventListener('DOMContentLoaded', function () {
    // Product filtering elements
    const filterContainer = document.querySelector('.filter-container');
    const productCards = document.querySelectorAll('.modern-product-card');
    const categoryTabs = document.querySelectorAll('.category-tab');

    // Additional filter options
    const setupFilters = () => {
        if (!filterContainer) return;

        // Create filter controls
        const filters = {
            applications: ['All', 'Residential', 'Commercial', 'Architectural', 'Safety', 'Security'],
            features: ['Energy Efficient', 'Sound Insulation', 'UV Protection', 'Heat Resistant', 'Privacy']
        };

        // Create filter dropdowns
        const applicationsFilter = createFilterDropdown('Filter by Application', 'application', filters.applications);
        const featuresFilter = createFilterDropdown('Filter by Feature', 'feature', filters.features);

        // Add sort dropdown
        const sortOptions = ['Newest', 'Popular', 'A-Z', 'Z-A'];
        const sortDropdown = createFilterDropdown('Sort By', 'sort', sortOptions);

        // Add clear filter button
        const clearButton = document.createElement('button');
        clearButton.className = 'filter-clear-btn';
        clearButton.innerHTML = '<i class="fas fa-times"></i> Clear Filters';
        clearButton.addEventListener('click', resetFilters);

        // Add filters to container
        filterContainer.appendChild(applicationsFilter);
        filterContainer.appendChild(featuresFilter);
        filterContainer.appendChild(sortDropdown);
        filterContainer.appendChild(clearButton);

        // Initialize filter event handlers
        initFilterHandlers();
    };

    /**
     * Creates a filter dropdown
     * @param {string} label - Dropdown label
     * @param {string} type - Filter type
     * @param {Array} options - Filter options
     * @returns {HTMLElement} - The dropdown element
     */
    const createFilterDropdown = (label, type, options) => {
        const dropdown = document.createElement('div');
        dropdown.className = 'filter-dropdown';

        dropdown.innerHTML = `
            <button class="filter-dropdown-btn">
                ${label} <i class="fas fa-chevron-down"></i>
            </button>
            <div class="filter-dropdown-content" data-filter-type="${type}">
                ${options.map((option, index) => `
                    <label class="filter-option">
                        <input type="radio" name="${type}" value="${option.toLowerCase()}" ${index === 0 ? 'checked' : ''}>
                        <span>${option}</span>
                    </label>
                `).join('')}
            </div>
        `;

        // Toggle dropdown on click
        const dropdownBtn = dropdown.querySelector('.filter-dropdown-btn');
        const dropdownContent = dropdown.querySelector('.filter-dropdown-content');

        dropdownBtn.addEventListener('click', () => {
            dropdownContent.classList.toggle('active');
            dropdownBtn.classList.toggle('active');

            // Close other open dropdowns
            document.querySelectorAll('.filter-dropdown-content.active').forEach(content => {
                if (content !== dropdownContent) {
                    content.classList.remove('active');
                    content.previousElementSibling.classList.remove('active');
                }
            });
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!dropdown.contains(e.target)) {
                dropdownContent.classList.remove('active');
                dropdownBtn.classList.remove('active');
            }
        });

        return dropdown;
    };

    /**
     * Initializes filter event handlers
     */
    const initFilterHandlers = () => {
        // Filter options change
        const filterOptions = document.querySelectorAll('.filter-option input');
        filterOptions.forEach(option => {
            option.addEventListener('change', applyFilters);
        });

        // Category tabs click
        categoryTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Remove active class from all tabs
                categoryTabs.forEach(t => t.classList.remove('active'));

                // Add active class to clicked tab
                tab.classList.add('active');

                // Apply filters
                applyFilters();
            });
        });
    };

    /**
     * Applies all current filters
     */
    const applyFilters = () => {
        // Get active filters
        const category = document.querySelector('.category-tab.active')?.getAttribute('data-target') || 'all';
        const application = document.querySelector('input[name="application"]:checked')?.value || 'all';
        const feature = document.querySelector('input[name="feature"]:checked')?.value || 'all';
        const sort = document.querySelector('input[name="sort"]:checked')?.value || 'newest';

        // Show/hide filter info
        updateActiveFiltersDisplay(category, application, feature);

        // Filter products
        filterProducts(category, application, feature);

        // Sort products
        sortProducts(sort);

        // Update results count
        updateResultsCount();
    };

    /**
     * Shows active filters information
     */
    const updateActiveFiltersDisplay = (category, application, feature) => {
        const filterInfo = document.querySelector('.filter-info');
        if (!filterInfo) return;

        let filterText = '';

        if (category !== 'all') {
            filterText += `<span class="filter-tag"><i class="fas fa-tag"></i> ${category.replace('-', ' ')}</span>`;
        }

        if (application !== 'all') {
            filterText += `<span class="filter-tag"><i class="fas fa-building"></i> ${application}</span>`;
        }

        if (feature !== 'all') {
            filterText += `<span class="filter-tag"><i class="fas fa-check-circle"></i> ${feature}</span>`;
        }

        if (filterText) {
            filterInfo.innerHTML = `<div class="active-filters">Active filters: ${filterText}</div>`;
            filterInfo.style.display = 'block';
        } else {
            filterInfo.style.display = 'none';
        }
    };

    /**
     * Filters products based on selected criteria
     */
    const filterProducts = (category, application, feature) => {
        let visibleCount = 0;

        productCards.forEach(card => {
            const cardCategory = card.getAttribute('data-category') || '';
            const cardApplication = card.getAttribute('data-application') || '';
            const cardFeatures = card.getAttribute('data-features') || '';

            // Check if card matches all filters
            const matchesCategory = category === 'all' || cardCategory === category;
            const matchesApplication = application === 'all' || cardApplication.includes(application);
            const matchesFeature = feature === 'all' || cardFeatures.includes(feature);

            if (matchesCategory && matchesApplication && matchesFeature) {
                card.style.display = 'block';
                visibleCount++;
            } else {
                card.style.display = 'none';
            }
        });

        // Show no results message if needed
        showNoResultsMessage(visibleCount === 0);
    };

    /**
     * Sorts products based on selected sort option
     */
    const sortProducts = (sortType) => {
        const productsGrid = document.querySelector('.modern-products-grid');
        if (!productsGrid) return;

        // Get visible products
        const visibleProducts = Array.from(productCards).filter(card => card.style.display !== 'none');

        // Sort products
        visibleProducts.sort((a, b) => {
            const titleA = a.querySelector('h3').textContent.trim();
            const titleB = b.querySelector('h3').textContent.trim();

            switch (sortType) {
                case 'a-z':
                    return titleA.localeCompare(titleB);
                case 'z-a':
                    return titleB.localeCompare(titleA);
                case 'popular':
                    const popularityA = parseInt(a.getAttribute('data-popularity') || '0');
                    const popularityB = parseInt(b.getAttribute('data-popularity') || '0');
                    return popularityB - popularityA;
                default: // newest
                    const dateA = a.getAttribute('data-date') || '';
                    const dateB = b.getAttribute('data-date') || '';
                    return dateB.localeCompare(dateA);
            }
        });

        // Reorder products in the DOM
        visibleProducts.forEach(product => {
            productsGrid.appendChild(product);
        });
    };

    /**
     * Shows or hides the no results message
     */
    const showNoResultsMessage = (show) => {
        let noResultsEl = document.querySelector('.no-results-message');

        if (show) {
            if (!noResultsEl) {
                noResultsEl = document.createElement('div');
                noResultsEl.className = 'no-results-message';
                noResultsEl.innerHTML = `
                    <i class="fas fa-search"></i>
                    <h3>No products match your filters</h3>
                    <p>Try adjusting your filters or <button class="reset-filters-btn">clear all filters</button></p>
                `;

                const productsGrid = document.querySelector('.modern-products-grid');
                if (productsGrid) {
                    productsGrid.parentNode.insertBefore(noResultsEl, productsGrid.nextSibling);

                    // Add event listener to reset button
                    noResultsEl.querySelector('.reset-filters-btn').addEventListener('click', resetFilters);
                }
            } else {
                noResultsEl.style.display = 'flex';
            }
        } else if (noResultsEl) {
            noResultsEl.style.display = 'none';
        }
    };

    /**
     * Updates the results count
     */
    const updateResultsCount = () => {
        const resultsCounter = document.querySelector('.results-counter');
        if (!resultsCounter) return;

        const visibleCount = Array.from(productCards).filter(card => card.style.display !== 'none').length;
        resultsCounter.textContent = `Showing ${visibleCount} of ${productCards.length} products`;
    };

    /**
     * Resets all filters to default
     */
    const resetFilters = () => {
        // Reset category tabs
        const allTab = document.querySelector('.category-tab[data-target="all"]');
        if (allTab) {
            categoryTabs.forEach(tab => tab.classList.remove('active'));
            allTab.classList.add('active');
        }

        // Reset filter dropdowns
        document.querySelectorAll('.filter-option input').forEach(input => {
            if (input.value === 'all') {
                input.checked = true;
            } else {
                input.checked = false;
            }
        });

        // Apply filters
        applyFilters();
    };

    // Initialize filters if filter container exists
    if (filterContainer && productCards.length > 0) {
        setupFilters();
    }
});