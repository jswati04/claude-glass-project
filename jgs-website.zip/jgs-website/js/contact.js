/**
 * Contact page JavaScript for JGS Industries website
 * Handles form validation, submission, and accordion functionality
 */

document.addEventListener('DOMContentLoaded', function () {
    // Contact Form Validation and Submission
    const contactForm = document.getElementById('contactForm');

    if (contactForm) {
        contactForm.addEventListener('submit', function (e) {
            e.preventDefault();

            // Basic form validation
            if (validateForm()) {
                // In a real implementation, this would send data to a server
                // For demo purposes, we'll just show a success message
                showFormSuccess();

                // Reset form after submission
                contactForm.reset();
            }
        });
    }

    // Form validation function
    function validateForm() {
        let isValid = true;
        const name = document.getElementById('name');
        const email = document.getElementById('email');
        const message = document.getElementById('message');

        // Clear previous error messages
        clearFormErrors();

        // Validate name
        if (!name.value.trim()) {
            displayError(name, 'Please enter your name');
            isValid = false;
        }

        // Validate email
        if (!email.value.trim()) {
            displayError(email, 'Please enter your email address');
            isValid = false;
        } else if (!isValidEmail(email.value)) {
            displayError(email, 'Please enter a valid email address');
            isValid = false;
        }

        // Validate message
        if (!message.value.trim()) {
            displayError(message, 'Please enter your message');
            isValid = false;
        }

        return isValid;
    }

    // Email validation using regex
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Display error message for a form field
    function displayError(element, message) {
        const formGroup = element.closest('.form-group');
        const errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        errorElement.textContent = message;
        errorElement.style.color = '#dc3545';
        errorElement.style.fontSize = '14px';
        errorElement.style.marginTop = '5px';
        formGroup.appendChild(errorElement);

        // Highlight the input field
        element.style.borderColor = '#dc3545';
    }

    // Clear all form error messages
    function clearFormErrors() {
        document.querySelectorAll('.error-message').forEach(error => {
            error.remove();
        });

        document.querySelectorAll('.form-control').forEach(input => {
            input.style.borderColor = '';
        });
    }

    // Show form success message
    function showFormSuccess() {
        // Create success message element
        const successMessage = document.createElement('div');
        successMessage.className = 'success-message';
        successMessage.textContent = 'Thank you for your message! We will get back to you shortly.';
        successMessage.style.backgroundColor = '#d4edda';
        successMessage.style.color = '#155724';
        successMessage.style.padding = '15px';
        successMessage.style.borderRadius = '5px';
        successMessage.style.marginBottom = '20px';

        // Add to the form
        contactForm.prepend(successMessage);

        // Remove after 5 seconds
        setTimeout(() => {
            successMessage.remove();
        }, 5000);
    }

    // Accordion Functionality for FAQ section
    const accordionHeaders = document.querySelectorAll('.accordion-header');

    if (accordionHeaders.length > 0) {
        accordionHeaders.forEach(header => {
            header.addEventListener('click', function () {
                // Toggle active class on the header
                this.classList.toggle('active');

                // Toggle the body panel
                const body = this.nextElementSibling;
                body.classList.toggle('active');
            });
        });
    }
});