/**
 * Products page JavaScript for JGS Industries website
 * Handles product navigation, 3D model controls, and interactive features
 */

document.addEventListener('DOMContentLoaded', function () {
    // Product category tab navigation
    const categoryTabs = document.querySelectorAll('.category-tab');

    if (categoryTabs.length > 0) {
        categoryTabs.forEach(tab => {
            tab.addEventListener('click', function () {
                // Remove active class from all tabs
                categoryTabs.forEach(t => t.classList.remove('active'));

                // Add active class to clicked tab
                this.classList.add('active');

                // Scroll to target section
                const targetId = this.getAttribute('data-target');
                const targetElement = document.getElementById(targetId);

                if (targetElement) {
                    // Scroll with offset for header
                    const headerHeight = document.querySelector('header').offsetHeight;
                    const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight - 20;

                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }

    // Check if URL contains a hash and scroll to that section
    if (window.location.hash) {
        const targetId = window.location.hash.substring(1);
        const targetElement = document.getElementById(targetId);

        if (targetElement) {
            // Delay to ensure page is fully loaded
            setTimeout(() => {
                const headerHeight = document.querySelector('header').offsetHeight;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight - 20;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });

                // Activate the corresponding tab
                const correspondingTab = document.querySelector(`.category-tab[data-target="${targetId}"]`);
                if (correspondingTab) {
                    categoryTabs.forEach(t => t.classList.remove('active'));
                    correspondingTab.classList.add('active');
                }
            }, 300);
        }
    }

    // 3D Model Controls Simulation
    const modelBtns = document.querySelectorAll('.model-btn');

    if (modelBtns.length > 0) {
        modelBtns.forEach(btn => {
            btn.addEventListener('click', function () {
                // Add visual feedback for button click
                this.classList.add('active');
                setTimeout(() => {
                    this.classList.remove('active');
                }, 300);

                // Get container and image
                const container = this.closest('.model-container');
                const image = container.querySelector('.product-image');

                // Simulate different actions based on button type
                if (this.title === 'Rotate left') {
                    simulateRotation(image, -15);
                } else if (this.title === 'Rotate right') {
                    simulateRotation(image, 15);
                } else if (this.title === 'Zoom in') {
                    simulateZoom(image, 1.1);
                } else if (this.title === 'Zoom out') {
                    simulateZoom(image, 0.9);
                }
            });
        });
    }

    // Simulate rotation effect on image
    function simulateRotation(image, degree) {
        let currentRotation = getComputedStyle(image).getPropertyValue('transform');

        // If no transform is set yet, start from matrix(1, 0, 0, 1, 0, 0)
        if (currentRotation === 'none') {
            currentRotation = 'matrix(1, 0, 0, 1, 0, 0)';
        }

        // Parse current transform matrix
        const matrix = currentRotation.match(/^matrix\((.+)\)$/);
        if (matrix) {
            const values = matrix[1].split(',');
            const a = parseFloat(values[0]);
            const b = parseFloat(values[1]);

            // Calculate new rotation
            const currentDegree = Math.round(Math.atan2(b, a) * (180 / Math.PI));
            const newDegree = currentDegree + degree;

            // Apply new rotation
            image.style.transform = `rotate(${newDegree}deg)`;
        } else {
            // If couldn't parse matrix, just set rotation
            image.style.transform = `rotate(${degree}deg)`;
        }
    }

    // Simulate zoom effect on image
    function simulateZoom(image, factor) {
        let currentScale = 1;

        // Get current scale if it exists
        const transform = getComputedStyle(image).getPropertyValue('transform');
        if (transform !== 'none') {
            const matrix = transform.match(/^matrix\((.+)\)$/);
            if (matrix) {
                const values = matrix[1].split(',');
                currentScale = parseFloat(values[0]);
            }
        }

        // Calculate and apply new scale
        const newScale = currentScale * factor;

        // Limit scale between 0.5 and 2
        if (newScale >= 0.5 && newScale <= 2) {
            image.style.transform = `scale(${newScale})`;
        }
    }
});