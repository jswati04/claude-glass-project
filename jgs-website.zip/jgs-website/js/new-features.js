/**
 * JGS Industries - Reviews & International Features
 * This script handles functionality for customer reviews and international section
 */

document.addEventListener('DOMContentLoaded', function () {
    // Customer Reviews Functionality
    initReviewsFilter();
    initReviewsSort();
    initReviewsPagination();

    // International Echo Functionality
    initWorldMap();
    initProjectsSlider();

    /**
     * Initializes review filtering functionality
     */
    function initReviewsFilter() {
        const filterButtons = document.querySelectorAll('.review-filter-btn');
        const reviewCards = document.querySelectorAll('.review-card');

        if (filterButtons.length === 0 || reviewCards.length === 0) return;

        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Update active button
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');

                // Get filter value
                const filter = button.getAttribute('data-filter');

                // Filter reviews
                reviewCards.forEach(card => {
                    const type = card.getAttribute('data-type');

                    if (filter === 'all' || type === filter) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }

    /**
     * Initializes review sorting functionality
     */
    function initReviewsSort() {
        const sortSelect = document.getElementById('review-sort');
        const reviewsGrid = document.querySelector('.reviews-grid');

        if (!sortSelect || !reviewsGrid) return;

        sortSelect.addEventListener('change', () => {
            const sortValue = sortSelect.value;
            const reviewCards = Array.from(document.querySelectorAll('.review-card[style*="display: block"]'));

            // Sort review cards
            reviewCards.sort((a, b) => {
                const ratingA = parseInt(a.getAttribute('data-rating'));
                const ratingB = parseInt(b.getAttribute('data-rating'));
                const dateA = a.getAttribute('data-date');
                const dateB = b.getAttribute('data-date');

                switch (sortValue) {
                    case 'highest':
                        return ratingB - ratingA;
                    case 'lowest':
                        return ratingA - ratingB;
                    default: // recent
                        return dateB.localeCompare(dateA);
                }
            });

            // Reorder in the DOM
            reviewCards.forEach(card => {
                reviewsGrid.appendChild(card);
            });
        });
    }

    /**
     * Initializes review pagination functionality
     */
    function initReviewsPagination() {
        const paginationButtons = document.querySelectorAll('.pagination-btn');

        if (paginationButtons.length === 0) return;

        paginationButtons.forEach(button => {
            button.addEventListener('click', () => {
                paginationButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');

                // In a real implementation, this would load the next page of reviews
                // For demo purposes, we'll just scroll to the top of the reviews section
                const reviewsSection = document.querySelector('.customer-reviews-section');
                if (reviewsSection) {
                    window.scrollTo({
                        top: reviewsSection.offsetTop,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }

    /**
     * Initializes interactive world map functionality
     */
    function initWorldMap() {
        const mapMarkers = document.querySelectorAll('.map-marker');
        const mapTooltip = document.getElementById('map-tooltip');

        if (mapMarkers.length === 0 || !mapTooltip) return;

        // Country data (in a real implementation, this would come from an API or database)
        const countryData = {
            'United Kingdom': { projects: 24, products: 'Tempered, Laminated, Double Glazed Glass' },
            'Germany': { projects: 27, products: 'Tempered, Laminated, Fire-Rated Glass' },
            'China': { projects: 18, products: 'Switchable, Bullet Proof Glass' },
            'Australia': { projects: 15, products: 'Double Glazed, Laminated Glass' },
            'Canada': { projects: 22, products: 'Tempered, Low-E, Insulated Glass' },
            'Japan': { projects: 13, products: 'Switchable, Fire-Rated Glass' },
            'United Arab Emirates': { projects: 20, products: 'Solar Control, Tempered Glass' },
            'Spain': { projects: 16, products: 'Decorative, Laminated Glass' }
        };

        mapMarkers.forEach(marker => {
            marker.addEventListener('mouseenter', (e) => {
                const country = marker.getAttribute('data-country');
                const data = countryData[country];

                if (data) {
                    // Update tooltip content
                    mapTooltip.querySelector('.tooltip-country').textContent = country;
                    mapTooltip.querySelector('.tooltip-projects').textContent = `${data.projects} Projects`;
                    mapTooltip.querySelector('.tooltip-products').textContent = data.products;

                    // Position tooltip
                    const markerRect = marker.getBoundingClientRect();
                    const mapRect = document.querySelector('.world-map-container').getBoundingClientRect();

                    const left = markerRect.left - mapRect.left + markerRect.width / 2;
                    const top = markerRect.top - mapRect.top - 10;

                    mapTooltip.style.left = `${left}px`;
                    mapTooltip.style.top = `${top - mapTooltip.offsetHeight}px`;
                    mapTooltip.style.opacity = '1';
                }
            });

            marker.addEventListener('mouseleave', () => {
                mapTooltip.style.opacity = '0';
            });
        });
    }

    /**
     * Initializes international projects slider
     */
    function initProjectsSlider() {
        const slides = document.querySelectorAll('.project-slide');
        const dots = document.querySelectorAll('.slider-dot');
        const prevArrow = document.querySelector('.prev-arrow');
        const nextArrow = document.querySelector('.next-arrow');

        if (slides.length === 0) return;

        let currentSlide = 0;

        // Show initial slide
        showSlide(currentSlide);

        // Previous slide button
        if (prevArrow) {
            prevArrow.addEventListener('click', () => {
                currentSlide = (currentSlide > 0) ? currentSlide - 1 : slides.length - 1;
                showSlide(currentSlide);
            });
        }

        // Next slide button
        if (nextArrow) {
            nextArrow.addEventListener('click', () => {
                currentSlide = (currentSlide < slides.length - 1) ? currentSlide + 1 : 0;
                showSlide(currentSlide);
            });
        }

        // Dot navigation
        dots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                currentSlide = index;
                showSlide(currentSlide);
            });
        });

        /**
         * Shows the specified slide
         * @param {number} index - The index of the slide to show
         */
        function showSlide(index) {
            // Hide all slides
            slides.forEach(slide => {
                slide.style.display = 'none';
            });

            // Show selected slide
            slides[index].style.display = 'flex';

            // Update dots
            dots.forEach((dot, i) => {
                dot.classList.toggle('active', i === index);
            });
        }

        // Auto-rotate slides (optional)
        let autoRotateInterval = setInterval(() => {
            currentSlide = (currentSlide < slides.length - 1) ? currentSlide + 1 : 0;
            showSlide(currentSlide);
        }, 8000);

        // Pause on hover
        const sliderContainer = document.querySelector('.projects-slider');
        if (sliderContainer) {
            sliderContainer.addEventListener('mouseenter', () => {
                clearInterval(autoRotateInterval);
            });

            sliderContainer.addEventListener('mouseleave', () => {
                autoRotateInterval = setInterval(() => {
                    currentSlide = (currentSlide < slides.length - 1) ? currentSlide + 1 : 0;
                    showSlide(currentSlide);
                }, 8000);
            });
        }
    }
});