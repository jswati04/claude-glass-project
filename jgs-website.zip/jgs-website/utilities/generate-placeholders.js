/**
 * JGS Industries - Placeholder Image Generator
 * 
 * This Node.js script generates placeholder images for the website
 * Run this script to create placeholder images for development
 * 
 * Requirements:
 * - Node.js
 * - npm install canvas fs
 */

const { createCanvas } = require('canvas');
const fs = require('fs');

// Create images directory if it doesn't exist
const imagesDir = './images';
if (!fs.existsSync(imagesDir)) {
    fs.mkdirSync(imagesDir);
}

// Configuration for image generation
const images = [
    { name: 'logo.png', width: 50, height: 50, text: 'JGS', bgColor: '#0056b3', textColor: '#ffffff' },
    { name: 'hero-bg.jpg', width: 1200, height: 600, text: 'Hero Background', bgColor: '#87CEEB', textColor: '#333333' },
    { name: 'page-header.jpg', width: 1200, height: 300, text: 'Page Header', bgColor: '#0056b3', textColor: '#ffffff' },
    { name: 'cta-bg.jpg', width: 1200, height: 300, text: 'CTA Background', bgColor: '#17a2b8', textColor: '#ffffff' },
    { name: 'facility.jpg', width: 600, height: 400, text: 'Facility', bgColor: '#f8f9fa', textColor: '#333333' },

    // Product Images
    { name: 'tempered-glass.jpg', width: 250, height: 200, text: 'Tempered Glass', bgColor: '#e9ecef', textColor: '#333333' },
    { name: 'double-glazed.jpg', width: 250, height: 200, text: 'Double Glazed', bgColor: '#e9ecef', textColor: '#333333' },
    { name: 'laminated-glass.jpg', width: 250, height: 200, text: 'Laminated Glass', bgColor: '#e9ecef', textColor: '#333333' },
    { name: 'switchable-glass.jpg', width: 250, height: 200, text: 'Switchable Glass', bgColor: '#e9ecef', textColor: '#333333' },

    // Large Product Images
    { name: 'tempered-glass-large.jpg', width: 600, height: 400, text: 'Tempered Glass', bgColor: '#e9ecef', textColor: '#333333' },
    { name: 'double-glazed-large.jpg', width: 600, height: 400, text: 'Double Glazed Glass', bgColor: '#e9ecef', textColor: '#333333' },
    { name: 'laminated-glass-large.jpg', width: 600, height: 400, text: 'Laminated Glass', bgColor: '#e9ecef', textColor: '#333333' },
    { name: 'fire-rated-glass.jpg', width: 600, height: 400, text: 'Fire Rated Glass', bgColor: '#e9ecef', textColor: '#333333' },
    { name: 'bullet-proof-glass.jpg', width: 600, height: 400, text: 'Bullet Proof Glass', bgColor: '#e9ecef', textColor: '#333333' },

    // Showroom Images
    { name: 'showroom-1.jpg', width: 400, height: 250, text: 'Showroom 1', bgColor: '#e9ecef', textColor: '#333333' },
    { name: 'showroom-2.jpg', width: 400, height: 250, text: 'Showroom 2', bgColor: '#e9ecef', textColor: '#333333' },
    { name: 'showroom-3.jpg', width: 400, height: 250, text: 'Showroom 3', bgColor: '#e9ecef', textColor: '#333333' },
    { name: 'showroom-4.jpg', width: 400, height: 250, text: 'Showroom 4', bgColor: '#e9ecef', textColor: '#333333' },
];

// Generate each placeholder image
images.forEach(img => {
    generatePlaceholder(img.name, img.width, img.height, img.text, img.bgColor, img.textColor);
});

/**
 * Generate a placeholder image
 * @param {string} filename - The name of the file to save
 * @param {number} width - The width of the image
 * @param {number} height - The height of the image
 * @param {string} text - The text to display on the image
 * @param {string} bgColor - The background color of the image
 * @param {string} textColor - The color of the text
 */
function generatePlaceholder(filename, width, height, text, bgColor, textColor) {
    // Create canvas with the specified dimensions
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Fill background
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, width, height);

    // Draw border
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, width, height);

    // Add dimensions as text
    ctx.font = 'bold 16px Arial';
    ctx.fillStyle = textColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${text} (${width}x${height})`, width / 2, height / 2);

    // If the image is small, adjust font size
    if (width < 100 || height < 100) {
        ctx.font = 'bold 10px Arial';
        ctx.fillText(`${text}`, width / 2, height / 2);
    }

    // Special handling for logo
    if (filename === 'logo.png') {
        // Clear canvas
        ctx.fillStyle = bgColor;
        ctx.fillRect(0, 0, width, height);

        // Draw a circular background
        ctx.beginPath();
        ctx.arc(width / 2, height / 2, Math.min(width, height) / 2 - 2, 0, Math.PI * 2);
        ctx.fillStyle = bgColor;
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Add JGS text
        ctx.font = 'bold 20px Arial';
        ctx.fillStyle = textColor;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('JGS', width / 2, height / 2);
    }

    // Save the image to file
    const buffer = canvas.toBuffer('image/jpeg');
    fs.writeFileSync(`${imagesDir}/${filename}`, buffer);

    console.log(`Generated: ${filename} (${width}x${height})`);
}

console.log('All placeholder images have been generated successfully!');
console.log(`Images are saved in the '${imagesDir}' directory.`);